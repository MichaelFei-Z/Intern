
"use strict";

let detection = require('./detection.js');

module.exports = {
  detection: detection,
};
